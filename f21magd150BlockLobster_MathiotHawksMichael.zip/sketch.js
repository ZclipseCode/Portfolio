//Sound-  MarcMatthewsMusic. “River_03.” Freesound, https://freesound.org/people/MarcMatthewsMusic/sounds/420556/. 2 Mar. 2018. WAV file.

var dx = 1;
var dxspeed = 0;
var dyspeed = 300;

var bLobsterFont;

var bPoints = 0;

var bNewBlock;

var bBlock1;
var bBlockX1;
var bBlockY1;
var bBlockDone1 = false;
var bBlockDead1 = false;

var bBlock2;
var bBlockX2;
var bBlockY2;
var bBlockDone2 = false;
var bBlockDead2 = false;

var bBlock3;
var bBlockX3;
var bBlockY3;
var bBlockDone3 = false;
var bBlockDead3 = false;

var bBlock4;
var bBlockX4;
var bBlockY4;
var bBlockDone4 = false;
var bBlockDead4 = false;

var bBlock5;
var bBlockX5;
var bBlockY5;
var bBlockDone5 = false;
var bBlockDead5 = false;

var bBlock6;
var bBlockX6;
var bBlockY6;
var bBlockDone6 = false;
var bBlockDead6 = false;

var bBlock7;
var bBlockX7;
var bBlockY7;
var bBlockDone7 = false;
var bBlockDead7 = false;

var bBlock8;
var bBlockX8;
var bBlockY8;
var bBlockDone8 = false;
var bBlockDead8 = false;

var bLobsterColor = 2;
var bGreenLobster;
var bBlueLobster;
var bRedLobster;
var bWhiteLobster;

var bRiver;

var bGameOver = false;

var river03;

function preload(){
  soundFormats('wav');
  river03 = loadSound('marcmatthewsmusic__river-03.wav');
}

function setup() {
  createCanvas(400, 400);
  
  print("Block Lobster");
  print("by Dylan Mathiot, Lucy Hawks, and Brian Michael")
  print(" ");
  print("Controls");
  print("Left and Right Arrow Keys to Move");
  print("1 Key for Green");
  print("2 Key for Blue");
  print("3 Key for Red");
  print("4 Key for White");
  print(" ");
  print("Credits");
  print("Dylan Mathiot- Programming");
  print("Lucy Hawks- Art");
  print("Brian Michael- Programming");
  print("Sound-  MarcMatthewsMusic. “River_03.” Freesound, https://freesound.org/people/MarcMatthewsMusic/sounds/420556/. 2 Mar. 2018. WAV file.")
  
  river03.loop();
  
  bLobsterFont = loadFont("Lobster-Regular.ttf");
  textFont(bLobsterFont);
  
  bBlock1 = new bBlock(1);
  bBlock2 = new bBlock(2);
  bBlock3 = new bBlock(2);
  bBlock4 = new bBlock(2);
  bBlock5 = new bBlock(5);
  bBlock6 = new bBlock(5);
  bBlock7 = new bBlock(5);
  bBlock8 = new bBlock(10);
  
  bGreenLobster = loadImage("greenLobster.png");
  bBlueLobster = loadImage("blueLobster.png");
  bRedLobster = loadImage("redLobster.png");
  bWhiteLobster = loadImage("whiteLobster.png");
  
  bRiver = loadImage("river.png");
}

function draw() {
  background(200);
  
  image(bRiver, 0, 0);
  
  if(bLobsterColor == 0){
    image(bGreenLobster, dxspeed, dyspeed, 50, 50);
  }
  
  if(bLobsterColor == 1){
    image(bBlueLobster, dxspeed, dyspeed, 50, 50);
  }
  
  if(bLobsterColor == 2){
    image(bRedLobster, dxspeed, dyspeed, 50, 50);
  }
  
  if(bLobsterColor == 3){
    image(bWhiteLobster, dxspeed, dyspeed, 50, 50);
  }
 
  if(keyIsDown(RIGHT_ARROW)){
    dxspeed = dx += 5;
  }
  if(keyIsDown(LEFT_ARROW)){
    dxspeed = dx -= 5;
  }
  
  bBlock1.draw();
  
  bBlockX1 = bBlock1.bReturnX();
  bBlockY1 = bBlock1.bReturnY();
  bBlockColor1 = bBlock1.bReturnColor();
  
  if(bBlockY1 == 350 && bBlockDone1 == false){
    bBlockDead1 = true;
  }
  
  if(bBlockDead1 == true){
    bBlock2.draw();
  }
  
  if(bBlockX1 >= dxspeed - 40 && bBlockX1 <= dxspeed + 40 && bBlockY1 >= dyspeed - 25 && bBlockY1 <= dyspeed + 25 && bLobsterColor != bBlockColor1){
    bGameOver = true;
  }
  
  if(bGameOver == true){
    background(0);
    
    push();
    fill(255);
    textSize(50);
    text("Gameover", 100, 200)
    pop();
  }
  
  if(bBlockY1 >= 350 && bBlockDone1 == false){
    bGameOver = true;
  }
  
  if(bBlockY2 >= 350 && bBlockDone2 == false){
    bGameOver = true;
  }
  
  if(bBlockY3 >= 350 && bBlockDone3 == false){
    bGameOver = true;
  }
  
  if(bBlockY4 >= 350 && bBlockDone4 == false){
    bGameOver = true;
  }
  
  if(bBlockY5 >= 350 && bBlockDone5 == false){
    bGameOver = true;
  }
  
  if(bBlockY6 >= 350 && bBlockDone6 == false){
    bGameOver = true;
  }
  
  if(bBlockY7 >= 350 && bBlockDone7 == false){
    bGameOver = true;
  }
  
  if(bBlockY8 >= 350 && bBlockDone8 == false){
    bGameOver = true;
  }
  
  if(bBlockX1 >= dxspeed - 40 && bBlockX1 <= dxspeed + 40 && bBlockY1 >= dyspeed - 25 && bBlockY1 <= dyspeed + 25 && bLobsterColor == bBlockColor1){
    bBlockDone1 = true;
  }
  
  //if green
  if(bBlockDone1 == true){
    if(bBlockColor1 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX1, bBlockY1, 50, 50);
      pop();
      bPoints = 50;
      bBlock2.draw();
    }
  }
  
  //if blue
  if(bBlockDone1 == true){
    if(bBlockColor1 == 1){
      push();
      fill('#457DED');
      rect(bBlockX1, bBlockY1, 50, 50);
      pop();
      bPoints = 50;
      bBlock2.draw();
    }
  }
  
  //if red
   if(bBlockDone1 == true){
    if(bBlockColor1 == 2){
      push();
      fill('#A80000');
      rect(bBlockX1, bBlockY1, 50, 50);
      pop();
      bPoints = 50;
      bBlock2.draw();
    }
  }
  
  //if white
  if(bBlockDone1 == true){
    if(bBlockColor1 == 3){
      push();
      fill(220);
      rect(bBlockX1, bBlockY1, 50, 50);
      pop();
      bPoints = 50;
      bBlock2.draw();
    }
  }
  
  bBlockX2 = bBlock2.bReturnX();
  bBlockY2 = bBlock2.bReturnY();
  bBlockColor2 = bBlock2.bReturnColor();
  
  if(bBlockY2 == 350 && bBlockDone2 == false){
    bBlockDead2 = true;
  }
  
  if(bBlockDead2 == true){
    bBlock3.draw();
  }
  
  if(bBlockX2 >= dxspeed - 40 && bBlockX2 <= dxspeed + 40 && bBlockY2 >= dyspeed - 25 && bBlockY2 <= dyspeed + 25 && bLobsterColor != bBlockColor2){
    bGameOver = true;
  }

if(bBlockX2 >= dxspeed - 40 && bBlockX2 <= dxspeed + 40 && bBlockY2 >= dyspeed - 25 && bBlockY2 <= dyspeed + 25 && bLobsterColor == bBlockColor2){
    bBlockDone2 = true;
  }
  
  //if green
  if(bBlockDone2 == true){
    if(bBlockColor2 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX2, bBlockY2, 50, 50);
      pop();
      bPoints = 100;
      bBlock3.draw();
    }
  }
  
  //if blue
  if(bBlockDone2 == true){
    if(bBlockColor2 == 1){
      push();
      fill('#457DED');
      rect(bBlockX2, bBlockY2, 50, 50);
      pop();
      bPoints = 100;
      bBlock3.draw();
    }
  }
  
  //if red
   if(bBlockDone2 == true){
    if(bBlockColor2 == 2){
      push();
      fill('#A80000');
      rect(bBlockX2, bBlockY2, 50, 50);
      pop();
      bPoints = 100;
      bBlock3.draw();
    }
  }
  
  //if white
  if(bBlockDone2 == true){
    if(bBlockColor2 == 3){
      push();
      fill(220);
      rect(bBlockX2, bBlockY2, 50, 50);
      pop();
      bPoints = 100;
      bBlock3.draw();
    }
  }
  
  bBlockX3 = bBlock3.bReturnX();
  bBlockY3 = bBlock3.bReturnY();
  bBlockColor3 = bBlock3.bReturnColor();
  
  if(bBlockY3 == 350 && bBlockDone3 == false){
    bBlockDead3 = true;
  }
  
  if(bBlockDead3 == true){
    bBlock4.draw();
  }
  
  if(bBlockX3 >= dxspeed - 40 && bBlockX3 <= dxspeed + 40 && bBlockY3 >= dyspeed - 25 && bBlockY3 <= dyspeed + 25 && bLobsterColor != bBlockColor3){
    bGameOver = true;
  }

if(bBlockX3 >= dxspeed - 40 && bBlockX3 <= dxspeed + 40 && bBlockY3 >= dyspeed - 25 && bBlockY3 <= dyspeed + 25 && bLobsterColor == bBlockColor3){
    bBlockDone3 = true;
  }
  
  //if green
  if(bBlockDone3 == true){
    if(bBlockColor3 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX3, bBlockY3, 50, 50);
      pop();
      bPoints = 150;
      bBlock4.draw();
    }
  }
  
  //if blue
  if(bBlockDone3 == true){
    if(bBlockColor3 == 1){
      push();
      fill('#457DED');
      rect(bBlockX3, bBlockY3, 50, 50);
      pop();
      bPoints = 150;
      bBlock4.draw();
    }
  }
  
  //if red
   if(bBlockDone3 == true){
    if(bBlockColor3 == 2){
      push();
      fill('#A80000');
      rect(bBlockX3, bBlockY3, 50, 50);
      pop();
      bPoints = 150;
      bBlock4.draw();
    }
  }
  
  //if white
  if(bBlockDone3 == true){
    if(bBlockColor3 == 3){
      push();
      fill(220);
      rect(bBlockX3, bBlockY3, 50, 50);
      pop();
      bPoints = 150;
      bBlock4.draw();
    }
  }
  
  bBlockX4 = bBlock4.bReturnX();
  bBlockY4 = bBlock4.bReturnY();
  bBlockColor4 = bBlock4.bReturnColor();
  
  if(bBlockY4 == 350 && bBlockDone4 == false){
    bBlockDead4 = true;
  }
  
  if(bBlockDead4 == true){
    bBlock4.draw();
  }
  
  if(bBlockX4 >= dxspeed - 40 && bBlockX4 <= dxspeed + 40 && bBlockY4 >= dyspeed - 25 && bBlockY4 <= dyspeed + 25 && bLobsterColor != bBlockColor4){
    bGameOver = true;
  }

if(bBlockX4 >= dxspeed - 40 && bBlockX4 <= dxspeed + 40 && bBlockY4 >= dyspeed - 25 && bBlockY4 <= dyspeed + 25 && bLobsterColor == bBlockColor4){
    bBlockDone4 = true;
  }
  
  //if green
  if(bBlockDone4 == true){
    if(bBlockColor4 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX4, bBlockY4, 50, 50);
      pop();
      bPoints = 200;
      bBlock5.draw();
    }
  }
  
  //if blue
  if(bBlockDone4 == true){
    if(bBlockColor4 == 1){
      push();
      fill('#457DED');
      rect(bBlockX4, bBlockY4, 50, 50);
      pop();
      bPoints = 200;
      bBlock5.draw();
    }
  }
  
  //if red
   if(bBlockDone4 == true){
    if(bBlockColor4 == 2){
      push();
      fill('#A80000');
      rect(bBlockX4, bBlockY4, 50, 50);
      pop();
      bPoints = 200;
      bBlock5.draw();
    }
  }
  
  //if white
  if(bBlockDone4 == true){
    if(bBlockColor4 == 3){
      push();
      fill(220);
      rect(bBlockX4, bBlockY4, 50, 50);
      pop();
      bPoints = 200;
      bBlock5.draw();
    }
  }
  
  bBlockX5 = bBlock5.bReturnX();
  bBlockY5 = bBlock5.bReturnY();
  bBlockColor5 = bBlock5.bReturnColor();
  
  if(bBlockY5 == 350 && bBlockDone5 == false){
    bBlockDead5 = true;
  }
  
  if(bBlockDead5 == true){
    bBlock6.draw();
  }
  
  if(bBlockX5 >= dxspeed - 40 && bBlockX5 <= dxspeed + 40 && bBlockY5 >= dyspeed - 25 && bBlockY5 <= dyspeed + 25 && bLobsterColor != bBlockColor5){
    bGameOver = true;
  }

if(bBlockX5 >= dxspeed - 40 && bBlockX5 <= dxspeed + 40 && bBlockY5 >= dyspeed - 25 && bBlockY5 <= dyspeed + 25 && bLobsterColor == bBlockColor5){
    bBlockDone5 = true;
  }
  
  //if green
  if(bBlockDone5 == true){
    if(bBlockColor5 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX5, bBlockY5, 50, 50);
      pop();
      bPoints = 250;
      bBlock6.draw();
    }
  }
  
  //if blue
  if(bBlockDone5 == true){
    if(bBlockColor5 == 1){
      push();
      fill('#457DED');
      rect(bBlockX5, bBlockY5, 50, 50);
      pop();
      bPoints = 250;
      bBlock6.draw();
    }
  }
  
  //if red
   if(bBlockDone5 == true){
    if(bBlockColor5 == 2){
      push();
      fill('#A80000');
      rect(bBlockX5, bBlockY5, 50, 50);
      pop();
      bPoints = 250;
      bBlock6.draw();
    }
  }
  
  //if white
  if(bBlockDone5 == true){
    if(bBlockColor5 == 3){
      push();
      fill(220);
      rect(bBlockX5, bBlockY5, 50, 50);
      pop();
      bPoints = 250;
      bBlock6.draw();
    }
  }
  
  bBlockX6 = bBlock6.bReturnX();
  bBlockY6 = bBlock6.bReturnY();
  bBlockColor6 = bBlock6.bReturnColor();
  
  if(bBlockY6 == 350 && bBlockDone6 == false){
    bBlockDead6 = true;
  }
  
  if(bBlockDead6 == true){
    bBlock7.draw();
  }
  
  if(bBlockX6 >= dxspeed - 40 && bBlockX6 <= dxspeed + 40 && bBlockY6 >= dyspeed - 25 && bBlockY6 <= dyspeed + 25 && bLobsterColor != bBlockColor6){
    bGameOver = true;
  }

if(bBlockX6 >= dxspeed - 40 && bBlockX6 <= dxspeed + 40 && bBlockY6 >= dyspeed - 25 && bBlockY6 <= dyspeed + 25 && bLobsterColor == bBlockColor6){
    bBlockDone6 = true;
  }
  
  //if green
  if(bBlockDone6 == true){
    if(bBlockColor6 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX6, bBlockY6, 50, 50);
      pop();
      bPoints = 300;
      bBlock7.draw();
    }
  }
  
  //if blue
  if(bBlockDone6 == true){
    if(bBlockColor6 == 6){
      push();
      fill('#457DED');
      rect(bBlockX6, bBlockY6, 50, 50);
      pop();
      bPoints = 300;
      bBlock7.draw();
    }
  }
  
  //if red
   if(bBlockDone6 == true){
    if(bBlockColor6 == 2){
      push();
      fill('#A80000');
      rect(bBlockX6, bBlockY6, 50, 50);
      pop();
      bPoints = 300;
      bBlock7.draw();
    }
  }
  
  //if white
  if(bBlockDone6 == true){
    if(bBlockColor6 == 3){
      push();
      fill(220);
      rect(bBlockX6, bBlockY6, 50, 50);
      pop();
      bPoints = 300;
      bBlock7.draw();
    }
  }
  
  bBlockX7 = bBlock7.bReturnX();
  bBlockY7 = bBlock7.bReturnY();
  bBlockColor7 = bBlock7.bReturnColor();
  
  if(bBlockY7 == 350 && bBlockDone7 == false){
    bBlockDead7 = true;
  }
  
  if(bBlockDead7 == true){
    bBlock8.draw();
  }
  
  if(bBlockX7 >= dxspeed - 40 && bBlockX7 <= dxspeed + 40 && bBlockY7 >= dyspeed - 25 && bBlockY7 <= dyspeed + 25 && bLobsterColor != bBlockColor7){
    bGameOver = true;
  }

if(bBlockX7 >= dxspeed - 40 && bBlockX7 <= dxspeed + 40 && bBlockY7 >= dyspeed - 25 && bBlockY7 <= dyspeed + 25 && bLobsterColor == bBlockColor7){
    bBlockDone7 = true;
  }
  
  //if green
  if(bBlockDone7 == true){
    if(bBlockColor7 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX7, bBlockY7, 50, 50);
      pop();
      bPoints = 350;
      bBlock8.draw();
    }
  }
  
  //if blue
  if(bBlockDone7 == true){
    if(bBlockColor7 == 7){
      push();
      fill('#457DED');
      rect(bBlockX7, bBlockY7, 50, 50);
      pop();
      bPoints = 350;
      bBlock8.draw();
    }
  }
  
  //if red
   if(bBlockDone7 == true){
    if(bBlockColor7 == 2){
      push();
      fill('#A80000');
      rect(bBlockX7, bBlockY7, 50, 50);
      pop();
      bPoints = 350;
      bBlock8.draw();
    }
  }
  
  //if white
  if(bBlockDone7 == true){
    if(bBlockColor7 == 3){
      push();
      fill(220);
      rect(bBlockX7, bBlockY7, 50, 50);
      pop();
      bPoints = 350;
      bBlock8.draw();
    }
  }
  
  bBlockX8 = bBlock8.bReturnX();
  bBlockY8 = bBlock8.bReturnY();
  bBlockColor8 = bBlock8.bReturnColor();
  
  if(bBlockY8 == 350 && bBlockDone8 == false){
    bBlockDead8 = true;
  }
  
  if(bBlockDead8 == true){
    push();
    fill(0);
    rect(bBlockX8, 350, 50, 50);
    pop();
  }
  
  if(bBlockX8 >= dxspeed - 40 && bBlockX8 <= dxspeed + 40 && bBlockY8 >= dyspeed - 25 && bBlockY8 <= dyspeed + 25 && bLobsterColor != bBlockColor8){
    bGameOver = true;
  }

if(bBlockX8 >= dxspeed - 40 && bBlockX8 <= dxspeed + 40 && bBlockY8 >= dyspeed - 25 && bBlockY8 <= dyspeed + 25 && bLobsterColor == bBlockColor8){
    bBlockDone8 = true;
  }
  
  //if green
  if(bBlockDone8 == true){
    if(bBlockColor8 == 0){
      push();
      fill('#5D9624');
      rect(bBlockX8, bBlockY8, 50, 50);
      pop();
      bPoints = 400;
      bGameOver = true;
    }
  }
  
  //if blue
  if(bBlockDone8 == true){
    if(bBlockColor8 == 8){
      push();
      fill('#457DED');
      rect(bBlockX8, bBlockY8, 50, 50);
      pop();
      bPoints = 400;
      bGameOver = true;
    }
  }
  
  //if red
   if(bBlockDone8 == true){
    if(bBlockColor8 == 2){
      push();
      fill('#A80000');
      rect(bBlockX8, bBlockY8, 50, 50);
      pop();
      bPoints = 400;
      bGameOver = true;
    }
  }
  
  //if white
  if(bBlockDone8 == true){
    if(bBlockColor8 == 3){
      push();
      fill(220);
      rect(bBlockX8, bBlockY8, 50, 50);
      pop();
      bPoints = 400;
      bGameOver = true;
    }
  }
  
  push();
  fill(255);
  text("Points: " + bPoints, 330, 30);
  pop();
}

function keyPressed(){
  //green
  if(keyCode === 49){
    bLobsterColor = 0;
  }
  
  //blue
  if(keyCode === 50){
    bLobsterColor = 1;
  }
  
  //red
  if(keyCode === 51){
    bLobsterColor = 2;
  }
  
  //white
  if(keyCode === 52){
    bLobsterColor = 3;
  }
}

class bBlock{
  constructor(bSpeed){
    var drandomColor;
    
    var bColor;
    
    var bRanX;
    var bY;
    var bYDecrement;
    var bBlockReady;
    
    this.drandomColor = random([0, 1, 2, 3]);
    
    this.bRanX = random([0, 50, 100, 150, 200, 250, 300, 350]);
    this.bY = 0;
    this.bYDecrement = 0;
    this.bBlockReady = false;
    this.bSpeed = bSpeed;
  }
 
  draw(){
    if(this.drandomColor == 0){
      //green
      this.bColor = '#9AFA3C';
    }
  
    if(this.drandomColor == 1){
      //blue
      this.bColor = '#45E9ED';
    }
  
    if(this.drandomColor == 2){
      //red
      this.bColor = '#FF0000';
    }
  
    if(this.drandomColor == 3){
      //white
      this.bColor = 255;
    }
    
    if(this.bBlockReady == false){
      push();
      fill(this.bColor);
      rect(this.bRanX, this.bY, 50, 50);
      pop();
 
      this.bY = this.bYDecrement += this.bSpeed;
    }
  }
 
  bReturnY(){
    return this.bY;
  }
  
  bReturnX(){
    return this.bRanX;
  }
  
  bReturnColor(){
    return this.drandomColor;
  }
}